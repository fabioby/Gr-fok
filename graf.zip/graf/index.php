<?php
require 'vendor/autoload.php';
header('Content-Type: text/plain');


$graf = new Graf(6);

$graf->hozzaad(0, 1);
$graf->hozzaad(1, 2);
$graf->hozzaad(0, 2);
$graf->hozzaad(2, 3);
$graf->hozzaad(3, 4);
$graf->hozzaad(4, 5);
$graf->hozzaad(2, 4);

$graf->torles(0,1);

print($graf);

echo $graf->szelessegBejar();
echo $graf->melysegBejar(0);

if($graf->isOsszefuggo()){
	echo "\nA gráf összefüggő\n";
} else {
	echo "\nA gráf NEM összefüggő\n";
}

$fa = $graf->feszitoFa();
echo("\nFeszítőfa:\n\n".$fa);