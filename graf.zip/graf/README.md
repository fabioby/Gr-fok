
# Gráf feladat (PHP változat) tudnivalók

A programot az index.php-val lehet indítani, akár böngészőből, akár konzolról a `php index.php` parancs futtatásával.

Az index.php már tartalmaz tesztadatokat. Itt kell majd tesztelni az újonnan felvett függvényeket is.

Nem kell include-olni, require-ölni semmit (a már meglévő autoload.php-n kívül). Ha az osztály neve megegyezik a php fájl nevével, akkor automatikusan használható lesz.

A projektet NetBeans segítségével hoztam létre, de természetesen bármilyen IDE / kódszerkesztő használható.
